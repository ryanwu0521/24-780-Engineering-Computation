/*
			 _   ___
			|_.'_____`._
		__ .'.-'     `-.`.		   Nestor Gomez
	   \  /,'           `.\		   Carnegie Mellon University
		\//               \\	   Eng. Computation, 24-780-B
		;;                 ::	   Prob Set 4
		||        O        ||	   Due Tues. Sept. 26, 2023
	   /,:                 ;;
	  /__\\               //	   Implement a Gear class to maintain
		  \`.           ,'/		   properties of gears. Also allow for
		  /_.`-._____.-'.'		   reading/writing files and display
			 `-._____.-'

*/
#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include <math.h>

// useful for managing coordinates
struct Point2D {
	float x, y;
};

class Gear {
private:
	std::string partID; // used for identification
	float pitch;        // given in teeth per inch
	int numbTeeth;
	Point2D loc;        // current location of gear {x, y}
	float angle;        // current rotation of gear in degrees

public:
	// reads data from a file over-riding any existing data
	void load(std::ifstream& inFile);

	// outputs all the data for a gear in format matching attached example
	void print(std::ostream& output = std::cout);

	// calculates and return the pitch diameter
	float pitchDiam() { return numbTeeth / pitch; };

	// draws the gear on graphics window
	void draw(bool fill = false, bool showID = false);

	std::string getID() { return partID; }

	// rotates the gear by the given angle (positive is CCW)
	void rotate(float rotAngle) { angle = std::fmod(angle+rotAngle, 360.); }
	//void rotate(float rotAngle) { angle += rotAngle; }

	// returns bottom left corner of gear bounding box
	Point2D minBound();
	// returns top right corner of gear bounding box
	Point2D maxBound();

	bool pointIsInGear(Point2D aPoint) {
		return ((aPoint.x - loc.x) * (aPoint.x - loc.x)
			+ (aPoint.y - loc.y) * (aPoint.y - loc.y))
			< (pitchDiam() * pitchDiam())/4.;
	}
};