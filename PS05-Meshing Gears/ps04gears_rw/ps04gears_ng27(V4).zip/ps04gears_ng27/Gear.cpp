#include <sstream>
#include <algorithm>    // std::min
#include <math.h>
#include "fssimplewindow.h"
#include "ysglfontdata.h"
#include "StringPlus.h"
#include "Gear.h"

using namespace std;

void Gear::load(std::ifstream& inFile)
{
	string wholeLineString;
	stringstream wholeLineStream;
	bool continueReading = true;
	int colonLocation;

	// go through file
	while (!inFile.eof() && continueReading) {
		// read the whole line
		getline(inFile, wholeLineString);

		// find the colon and prepare to read from stringstream after the colon
		if ((colonLocation = wholeLineString.find(":")) != string::npos)
			wholeLineStream.str(wholeLineString.substr(colonLocation + 1));

		// when the find() function doesn't find it, string::npos is returned
		if (wholeLineString.find("partID") != string::npos) {
			partID = StringPlus::trim(
				wholeLineString.substr(colonLocation + 1));
		}
		else if (wholeLineString.find("pitch") != string::npos) {
			wholeLineStream >> pitch;
		}
		else if (wholeLineString.find("numbTeeth") != string::npos) {
			wholeLineStream >> numbTeeth;
		}
		else if (wholeLineString.find("startX") != string::npos) {
			wholeLineStream >> loc.x;
		}
		else if (wholeLineString.find("startY") != string::npos) {
			wholeLineStream >> loc.y;
		}
		else if (wholeLineString.find("startAngle") != string::npos) {
			wholeLineStream >> angle;
		}

		else if (wholeLineString.find("Gear End") != string::npos) {
			continueReading = false;
		}

		wholeLineStream.clear(); // get ready for next line
	}
}

void Gear::print(std::ostream& output)
{
	output << "Gear: " << endl;
	output << "\tpartID: " << partID << endl;
	output << "\tpitch: " << pitch << endl;
	output << "\tnumbTeeth: " << numbTeeth << endl;
	output << "\tstartX: " << loc.x << endl;
	output << "\tstartY: " << loc.y << endl;
	output << "\tstartAngle: " << angle << endl;
	output << "Gear End: " << endl;
}

void Gear::draw(bool fill, bool showID)
{
	float radius = numbTeeth / pitch / 2.;
	float module = radius * 2 / numbTeeth;
	float angleStepRad = 360. / numbTeeth * atan(1.) / 45.;

	glTranslated(loc.x, loc.y, 0.);
	glRotated(angle, 0., 0., 1.);
	float topWidth = 1.0 * module;
	float botWidth = 1.8 * module;
	float radiusToToothSide = sqrt(pow(radius - 1.25 * module, 2.) + pow(botWidth / 2., 2.));
	float theta = angleStepRad - atan(botWidth / 2. / (radius - 1.25 * module));
	Point2D extraSegment = { radiusToToothSide * cos(theta), radiusToToothSide * sin(theta) };
	// draw the teeth
	for (int i = 0; i < numbTeeth; i++) {

		if (!fill) {
			glBegin(GL_LINE_STRIP);
			glVertex2d(extraSegment.x, extraSegment.y);
			glVertex2d(radius - 1.25 * module, botWidth / 2.);
			glVertex2d(radius + 1.00 * module, topWidth / 2.);
			glVertex2d(radius + 1.00 * module, -topWidth / 2.);
			glVertex2d(radius - 1.25 * module, -botWidth / 2.);
			glEnd();
		}
		else {
			// filled in (two convex shapes)
			glBegin(GL_POLYGON);
			glVertex2d(0., 0.);
			glVertex2d(radius - 1.25 * module, botWidth / 2.);
			glVertex2d(radius + 1.00 * module, topWidth / 2.);
			glVertex2d(radius + 1.00 * module, -topWidth / 2.);
			glVertex2d(radius - 1.25 * module, -botWidth / 2.);
			glEnd();
			glBegin(GL_POLYGON);
			glVertex2d(0., 0.);
			glVertex2d(extraSegment.x, extraSegment.y);
			glVertex2d(radius - 1.25 * module, botWidth / 2.);
			glEnd();
		}
		glRotated(360. / numbTeeth, 0., 0., 1.);
	}

	// show partID (not the way I wanted it, but OK for now)
	if (showID) {
		glColor3ub(255, 255, 0);  // yellow
		glRasterPos2i(0, 0);  // sets position
		YsGlDrawFontBitmap8x12(partID.c_str());

		// used the following code to prove that YsGLDrawFont never rotates :-(
		//glBegin(GL_LINES);
		//glVertex2f(0, 0);
		//glVertex2f(radius, 0);
		//glEnd();

		glColor3ub(0, 0, 0); // black

	}

	// draw pitch circle (useful for debugging)
	//float PI = atan(1.) * 4.;
	//glBegin(GL_LINE_LOOP);
	//for (float angle = 0; angle < 2* PI; angle += PI/32) // 64 points
	//	glVertex2d(loc.x + radius* cos(angle), loc.y + radius * sin(angle));
	//glEnd();

	glRotated(-angle, 0., 0., 1.);
	glTranslated(-loc.x, -loc.y, 0.);

}

Point2D Gear::minBound()
{
	// use addendum dimension
	float radius = pitchDiam() / 2.;
	float module = pitchDiam() / numbTeeth;
	return { loc.x - radius - module, loc.y - radius - module };
}
Point2D Gear::maxBound()
{
	// use addendum dimension
	float radius = pitchDiam() / pitch / 2.;
	float module = pitchDiam() / numbTeeth;
	return { loc.x + radius + module, loc.y + radius + module };
}

